import assert from 'node:assert/strict';
process.env.SRA_LUCK_MASTER_KEY='m'.repeat(64);
process.env.SRA_LUCK_ADMIN_TOKEN='a'.repeat(64);
process.env.UPSTASH_REDIS_REST_URL='https://test-redis.example.invalid';
process.env.UPSTASH_REDIS_REST_TOKEN='test-redis-token';
process.env.SRA_LUCK_ALLOWED_EXTENSION_ORIGINS='chrome-extension://'+'a'.repeat(32);
const kv=new Map();let checks=0;
globalThis.fetch=async(url,opts)=>{
 assert.equal(url,'https://test-redis.example.invalid');
 assert.equal(opts.headers.Authorization,'Bearer test-redis-token');
 const [cmd,k,v,...rest]=JSON.parse(opts.body);let result=null;
 if(cmd==='GET')result=kv.get(k)||null;
 if(cmd==='SET'){
  if(rest.includes('NX')&&kv.has(k))result=null;
  else {kv.set(k,v);result='OK';}
 }
 return new Response(JSON.stringify({result}),{status:200,headers:{'content-type':'application/json'}});
};
const {default:cloud}=await import('./api/index.mjs');
const origin='chrome-extension://'+'a'.repeat(32);
const bearer='Bearer '+'a'.repeat(64);
async function send(route,method='GET',data=null,auth=bearer,from=origin){
 const h={'authorization':auth,'origin':from};if(data)h['content-type']='application/json';
 const r=await cloud(new Request('https://sra-luck-api.vercel.app/api/index?route='+encodeURIComponent(route.replace(/^\/api\//,'')),{method,headers:h,...(data?{body:JSON.stringify(data)}:{})}));
 let result={};try{result=await r.json();}catch{}return {status:r.status,data:result,headers:r.headers};
}
function test(cond,desc){assert.ok(cond,desc);checks++;}
let r=await send('/api/state');test(r.status===200&&r.data.connections.length===0,'empty state');
test(r.data.policy.free_only===true,'free only defaults on');
r=await send('/api/state','GET',null,'Bearer wrong');test(r.status===401,'invalid token rejected');
r=await send('/api/state','GET',null,bearer,'https://malicious.example');test(r.status===403,'unexpected origin rejected');
r=await send('/api/connections','POST',{name:'bad',type:'ollama',base_url:'http://127.0.0.1:11434',enabled:true});test(r.status===400&&r.data.error.code==='CLOUD_LOCALHOST_UNREACHABLE','cloud rejects local PC');
r=await send('/api/connections','POST',{name:'Externo',type:'openai_compatible',base_url:'https://api.groq.com/openai/v1',api_key:'gsk-example-test',enabled:true});test(r.status===200&&!!r.data.id,'provider added');
let saved=kv.get('sra-luck:central-ia:v1');test(saved&&!saved.includes('gsk-example-test'),'provider key encrypted');
r=await send('/api/state');test(r.status===200&&r.data.connections.length===1&&r.data.connections[0].has_key===true,'provider persisted');
test(!JSON.stringify(r.data).includes('secret'),'no secret on state');
const id=r.data.connections[0].id;
r=await send('/api/settings','PUT',{free_only:false,agents:{cobranca:{primary:id,model:'llama-example',allowExternal:false,fallback:[]},atendimento:{primary:id,model:'llama-example',allowExternal:true,fallback:[]}}});test(r.status===200&&!r.data.policy.free_only,'policy persisted');
r=await send('/api/state');test(r.data.agents.cobranca.allowExternal===false&&r.data.agents.atendimento.allowExternal===true,'agents isolated');
r=await send('/api/generate','POST',{agent:'cobranca',task:'reply',context_authorized:true,messages:[{role:'user',content:'Teste fictício'}],request_id:'a'.repeat(26)});test(r.status===403&&r.data.error.code==='CONSENT_REQUIRED','no external provider without agent consent');
r=await send('/api/generate','POST',{agent:'cobranca',task:'reply',context_authorized:true,messages:[{role:'user',content:'Teste fictício'}],request_id:'a'.repeat(26)});test(r.status===409&&r.data.error.code==='DUPLICATE_REQUEST','cross invocation dedup');
r=await send('/api/settings','PUT',{free_only:true});test(r.status===200,'freeonly enabled');
r=await send('/api/generate','POST',{agent:'atendimento',context_authorized:true,messages:[{role:'user',content:'Teste fictício'}],request_id:'b'.repeat(26)});test(r.status===403&&r.data.error.code==='FREE_ONLY_BLOCK','billable provider blocked');
r=await send('/api/connections/'+id,'DELETE');test(r.status===200,'remove connection');
r=await send('/api/state');test(r.data.connections.length===0&&!r.data.agents.cobranca.primary,'state cleanup');
r=await cloud(new Request('https://sra-luck-api.vercel.app/api/index?route=health',{method:'OPTIONS',headers:{origin}}));test(r.status===204,'preflight works');
console.log(checks+' testes de contrato da Central de IA cloud: APROVADOS (provedor e Redis simulados).');
