/** Sra. Luck Central de IA — companion local, Node 20+, sem dependências externas. */
import http from 'node:http';
import https from 'node:https';
import {lookup} from 'node:dns/promises';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import net from 'node:net';

const PORT=Number(process.env.SRA_LUCK_PORT||45421);
const TIMEOUT=Math.max(500,Math.min(30000,Number(process.env.SRA_LUCK_PROVIDER_TIMEOUT_MS||30000)));
const HOST='127.0.0.1';
const DIRECTORY=process.env.SRA_LUCK_DATA_DIR||path.join(os.homedir(),'.sra-luck-ia');
const SECRET=process.env.SRA_LUCK_MASTER_KEY||'';
const TOKEN=process.env.SRA_LUCK_ADMIN_TOKEN||'';
if(SECRET.length<32||TOKEN.length<32){console.error('Configure SRA_LUCK_MASTER_KEY e SRA_LUCK_ADMIN_TOKEN (mínimo de 32 caracteres cada). Veja README.');process.exit(1);}
fs.mkdirSync(DIRECTORY,{recursive:true,mode:0o700});
const STORE=path.join(DIRECTORY,'connections.json');
const LOGS=[];
const recentlyUsedRequests=new Map();
const ALLOWED=new Set(['api.openai.com','api.groq.com','openrouter.ai','generativelanguage.googleapis.com','api.anthropic.com','api.deepseek.com',...(process.env.SRA_LUCK_ALLOWED_EXTERNAL_HOSTS||'').split(',').map(x=>x.trim().toLowerCase()).filter(Boolean)]);
const master=crypto.scryptSync(SECRET,'sra-luck-ia-aes-2026',32);
const profiles={
  cobranca:'Você é especialista em cobrança humanizada da Sra. Luck. Responda com naturalidade, objetividade, empatia e estratégia respeitosa. Considere a última mensagem, as objeções e o contexto autorizado. Não invente pagamento, multa, juros, desconto, prazo, aprovação nem política. Não ameace nem constranja. Propostas financeiras exigem revisão humana. Entregue apenas o texto solicitado.',
  atendimento:'Você é especialista em atendimento humanizado da Sra. Luck. Escreva de forma natural, acolhedora quando cabível, objetiva e profissional. Não invente serviços, contratos, aprovações ou ações executadas. Peça somente informações necessárias. Entregue apenas o texto solicitado.'
};
const templateInstruction='Organize um template reutilizável da Sra. Luck, com tom humano, natural e apropriado à área. Não invente valores, descontos, compromissos ou aprovações. Responda somente JSON válido {"title":"...","body":"..."} com título curto e corpo com parágrafos. Variáveis permitidas: {{primeiro_nome}}, {{saudacao_capitalizada}}, {{saudacao}}, {{data}}.';
const fresh=()=>({version:1,policy:{free_only:true},agents:{cobranca:{primary:'',model:'',fallback:[],allowExternal:false},atendimento:{primary:'',model:'',fallback:[],allowExternal:false}},connections:[]});
function encrypt(value){if(!value)return '';const iv=crypto.randomBytes(12),cipher=crypto.createCipheriv('aes-256-gcm',master,iv),bytes=Buffer.concat([cipher.update(String(value),'utf8'),cipher.final()]);return [iv,cipher.getAuthTag(),bytes].map(x=>x.toString('base64url')).join('.');}
function decrypt(value){if(!value)return '';const [a,b,c]=value.split('.');const decipher=crypto.createDecipheriv('aes-256-gcm',master,Buffer.from(a,'base64url'));decipher.setAuthTag(Buffer.from(b,'base64url'));return Buffer.concat([decipher.update(Buffer.from(c,'base64url')),decipher.final()]).toString('utf8');}
let state;
try{state=fs.existsSync(STORE)?JSON.parse(fs.readFileSync(STORE,'utf8')):fresh();}catch{throw new Error('Armazenamento inacessível/corrompido. Não sobrescreva o arquivo: confira a chave mestre.');}
function save(){const temp=STORE+'.tmp';fs.writeFileSync(temp,JSON.stringify(state,null,2),{mode:0o600});fs.renameSync(temp,STORE);try{fs.chmodSync(STORE,0o600);}catch{}}
function publicState(){return {policy:state.policy,agents:state.agents,connections:state.connections.map(({secret,...c})=>({...c,has_key:!!secret})),logs:LOGS.slice(-50).reverse()};}
class ApiError extends Error{constructor(code,message,status=400,retryable=false){super(message);this.code=code;this.status=status;this.retryable=retryable;}}
function fail(code,message,status=400,retryable=false){throw new ApiError(code,message,status,retryable);}
const isLoopback=h=>['localhost','127.0.0.1','[::1]','::1'].includes(h);
const allowedKinds=['ollama','ollama_openai','freellmapi','openai_compatible'];
function parseTarget(record){
 const kind=record.type;let u;
 try{u=new URL(record.base_url);}catch{fail('INVALID_URL','URL do provedor inválida.');}
 if(u.username||u.password||u.hash||u.search)fail('INVALID_URL','Não inclua senha, fragmento ou parâmetros na URL.');
 if(!['http:','https:'].includes(u.protocol))fail('INVALID_URL','Protocolo não permitido.');
 if(u.protocol==='http:'&&!isLoopback(u.hostname))fail('INSECURE_URL','HTTP só é permitido em loopback.');
 if(isLoopback(u.hostname)){
  if(u.protocol!=='http:')fail('INVALID_URL','Para servidores locais use HTTP loopback.');
  const port=Number(u.port||80);
  // Impede SSRF em qualquer outro serviço local.
  const safePorts=['ollama','ollama_openai'].includes(kind)?[11434]:kind==='freellmapi'?[31415]:[];
  if(!safePorts.includes(port))fail('SSRF_BLOCK','Porta local não autorizada para este provedor.');
 }else{
  if(u.protocol!=='https:'||!ALLOWED.has(u.hostname.toLowerCase()))fail('SSRF_BLOCK','Host remoto não permitido. Configure allowlist administrativa, somente com autorização.');
 }
 return u;
}
function normalizedUrl(record,kind){const u=parseTarget(record);const base=u.pathname.replace(/\/+$/,'');if(kind==='ollama'){
  u.pathname=base.replace(/\/(api|v1)(?:\/.*)?$/,'')+'/api';
 }else if(kind==='freellmapi'||kind==='ollama_openai'){
  u.pathname=base.endsWith('/v1')?base:base+'/v1';
 }else{
  u.pathname=base.replace(/\/chat\/completions$/,'').replace(/\/models$/,'');
 }return u;}
function endpoint(record,kind,operation){const u=normalizedUrl(record,kind);u.pathname=u.pathname.replace(/\/+$/,'')+(kind==='ollama'?(operation==='list'?'/tags':'/chat'):(operation==='list'?(kind==='freellmapi'?'/models':'/models'):'/chat/completions'));if(kind==='freellmapi'&&operation==='list')u.searchParams.set('execution_status','ready');return u;}
function ipv4Private(ip){const n=ip.split('.').map(Number);return n[0]===10||n[0]===127||n[0]===0||n[0]===169&&n[1]===254||n[0]===172&&n[1]>=16&&n[1]<=31||n[0]===192&&n[1]===168||n[0]>=224||n[0]===100&&n[1]>=64&&n[1]<=127||n[0]===192&&n[1]===0||n[0]===198&&n[1]>=18&&n[1]<=19;}
function publicIp(ip){if(net.isIP(ip)===4)return !ipv4Private(ip);if(net.isIP(ip)===6){const lower=ip.toLowerCase();return !(lower==='::1'||lower==='::'||lower.startsWith('fc')||lower.startsWith('fd')||lower.startsWith('fe8')||lower.startsWith('fe9')||lower.startsWith('fea')||lower.startsWith('feb')||lower.startsWith('::ffff:'));}return false;}
async function secureRequest(url,{method='GET',body,headers={}}={}){
 url=new URL(url);
 if(url.hostname==='localhost')url.hostname='127.0.0.1';
 const local=isLoopback(url.hostname);let pinned;
 if(!local){const all=await lookup(url.hostname,{all:true,verbatim:true});if(!all.length||all.some(r=>!publicIp(r.address)))fail('SSRF_BLOCK','Resolução de domínio bloqueada por segurança.');pinned=all[0];}
 const requestBody=body?JSON.stringify(body):'';
 if(requestBody.length>40000)fail('REQUEST_TOO_LARGE','Limite de 40 KB por solicitação.');
 return new Promise((resolve,reject)=>{
  const driver=url.protocol==='https:'?https:http;
  const req=driver.request(url,{method,timeout:TIMEOUT,headers:{'Content-Type':'application/json','Accept':'application/json',...headers,...(body?{'Content-Length':Buffer.byteLength(requestBody)}:{})},...(pinned?{lookup:(_hostname,_opts,cb)=>cb(null,pinned.address,pinned.family)}:{})},res=>{
   let chunks=[],bytes=0;
   res.on('data',chunk=>{bytes+=chunk.length;if(bytes>1024*1024){req.destroy(new Error('Resposta acima do limite de 1 MB.'));return;}chunks.push(chunk);});
   res.on('end',()=>{let data;try{data=JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{data={};}resolve({status:res.statusCode||500,data});});
  });
  req.on('timeout',()=>req.destroy(new ApiError('TIMEOUT','O provedor demorou demais para responder.',504,false)));
  req.on('error',error=>reject(error instanceof ApiError?error:new ApiError('UNREACHABLE','Não foi possível alcançar o provedor.',502,true)));
  if(body)req.write(requestBody);req.end();
 });
}
function scrubContext(text){return String(text).replace(/\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b/g,'[CPF oculto]').replace(/\b\d{2}\.?\d{3}\.?\d{3}\/?\d{4}-?\d{2}\b/g,'[CNPJ oculto]').replace(/\b[\w.+-]+@[\w.-]+\.[A-Z]{2,}\b/gi,'[e-mail oculto]').replace(/(?:\+55\s?)?\(?\d{2}\)?[\s-]?9?\d{4}[\s-]?\d{4}\b/g,'[telefone oculto]');}
function headerFor(c){const secret=decrypt(c.secret||'');return secret?{Authorization:`Bearer ${secret}`}:{ };}
function getConnection(id){const c=state.connections.find(c=>c.id===id&&c.enabled);if(!c)fail('NOT_CONFIGURED','Conexão inexistente ou desativada.',404);parseTarget(c);return c;}
async function discover(id){const c=getConnection(id),start=Date.now();const url=endpoint(c,c.type,'list');const result=await secureRequest(url,{headers:headerFor(c)});
 if(result.status>=400)fail('PROVIDER_ERROR',result.status===401?'Chave rejeitada pelo provedor.':`Consulta de modelos: HTTP ${result.status}.`,502,result.status===429||result.status===503);
 const models=(c.type==='ollama'?(result.data.models||[]):(result.data.data||result.data.models||[])).filter(m=>m&&typeof m==='object').map(m=>({id:String(m.id||m.name||m.model||''),status:m.execution_status|| (['ollama','ollama_openai'].includes(c.type)?'installed':'unknown')})).filter(x=>x.id&&x.id.length<=180);
 const unique=[...new Map(models.map(x=>[x.id,x])).values()];c.last_check=new Date().toISOString();c.last_latency_ms=Date.now()-start;c.models=unique.slice(0,1000);save();
 return {models:c.models,latency_ms:c.last_latency_ms,confirmed:true};
}
function isLocalOnly(c,model){return ['ollama','ollama_openai'].includes(c.type)&&isLoopback(new URL(c.base_url).hostname)&&!/:cloud\b/i.test(model)&&!/^cloud[/:]/i.test(model);}
function gate(c,model,agent){
 if(state.policy.free_only&&!isLocalOnly(c,model))fail('FREE_ONLY_BLOCK','Modo custo zero: somente modelos Ollama locais instalados são autorizados.',403);
 if(!isLocalOnly(c,model)&&!agent.allowExternal)fail('CONSENT_REQUIRED','Este agente não está autorizado a enviar dados para provedores externos.',403);
 if(!model)fail('MODEL_MISSING','Selecione um modelo para este agente.');
}
function modelReady(c,model){if(c.type==='freellmapi'&&/^auto(?::(fast|smart|reliable))?$/.test(model))return true;return c.models?.some(m=>m.id===model&&(!m.status||m.status==='ready'||m.status==='installed'||m.status==='unknown'));}
async function inference(c,model,user,agent,task,params){
 const url=endpoint(c,c.type,'chat'),messages=[{role:'system',content:profiles[agent]+(task==='template'?'\n'+templateInstruction:'')},...user];
 const body=c.type==='ollama'?{model,messages,stream:false,options:{num_predict:params.max_tokens,temperature:params.temperature}}:{model,messages,stream:false,max_tokens:params.max_tokens,temperature:params.temperature};
 const started=Date.now(),r=await secureRequest(url,{method:'POST',headers:headerFor(c),body});
 if(r.status>=400){const retryable=[429,502,503,504].includes(r.status);fail(r.status===429?'RATE_LIMIT':'PROVIDER_ERROR',`Falha no provedor (HTTP ${r.status}).`,r.status,retryable);}
 const content=c.type==='ollama'?r.data.message?.content:r.data.choices?.[0]?.message?.content;
 if(typeof content!=='string'||!content.trim())fail('EMPTY_RESPONSE','O modelo não retornou texto utilizável.',502);
 const usage=c.type==='ollama'?{input_tokens:r.data.prompt_eval_count??null,output_tokens:r.data.eval_count??null}: {input_tokens:r.data.usage?.prompt_tokens??null,output_tokens:r.data.usage?.completion_tokens??null};
 return {text:content.trim(),model:r.data.model||model,provider:c.id,latency_ms:Date.now()-started,usage};
}
function log(type,meta={}){LOGS.push({at:new Date().toISOString(),type,...meta});if(LOGS.length>100)LOGS.shift();}
async function generate(body){
 const agentName=body.agent;if(!Object.hasOwn(profiles,agentName))fail('INVALID_AGENT','Agente não reconhecido.');
 const agent=state.agents[agentName];if(!body.context_authorized)fail('CONSENT_REQUIRED','Confirme o envio do contexto antes de gerar.',403);
 if(!['reply','template'].includes(body.task||'reply'))fail('INVALID_TASK','Tarefa inválida.');
 const raw=body.messages;if(!Array.isArray(raw)||!raw.length||raw.length>30)fail('INVALID_MESSAGES','Envie até 30 mensagens autorizadas.');
 const msgs=raw.map(m=>({role:m.role==='assistant'?'assistant':'user',content:scrubContext(String(m.content||'').slice(0,12000))}));
 if(msgs.some(m=>!m.content.trim()))fail('INVALID_MESSAGES','Há uma mensagem vazia.');
 const params={max_tokens:Math.min(1600,Math.max(100,Number(body.max_tokens)||1000)),temperature:Math.min(1,Math.max(0,Number(body.temperature)||0.5))};
 const routes=[{id:agent.primary,model:agent.model},...(Array.isArray(agent.fallback)?agent.fallback:[])].filter(r=>r.id&&r.model);
 if(!routes.length)fail('NOT_CONFIGURED','Configure o modelo principal do agente.',400);
 let last;
 for(let i=0;i<routes.length&&i<3;i++){
  const r=routes[i],c=getConnection(r.id);gate(c,r.model,agent);
  if(state.policy.free_only){await discover(c.id);if(!modelReady(c,r.model))fail('FREE_MODEL_UNVERIFIED','O modelo local não foi confirmado como instalado.',403);}
  try{const result=await inference(c,r.model,msgs,agentName,body.task||'reply',params);
    log('success',{agent:agentName,provider:c.name,model:result.model,latency_ms:result.latency_ms,usage:result.usage});return result;
  }catch(error){last=error;log('error',{agent:agentName,provider:c.name,model:r.model,code:error.code||'UNREACHABLE'});
    const allowedFallback=error.retryable&&!(c.type==='freellmapi'&&r.model.startsWith('auto'));
    if(!allowedFallback||i===routes.length-1)break;
  }
 }
 throw last||new ApiError('NO_ROUTE','Nenhum provedor autorizado disponível.',503);
}
function json(res,status,data){const raw=JSON.stringify(data);res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Length':Buffer.byteLength(raw)});res.end(raw);}
function tokenMatches(given){const a=Buffer.from(given||''),b=Buffer.from(TOKEN);return a.length===b.length&&crypto.timingSafeEqual(a,b);}
async function readBody(req){let chunks=[],size=0;for await(const chunk of req){size+=chunk.length;if(size>65536)fail('REQUEST_TOO_LARGE','Corpo acima de 64 KB.',413);chunks.push(chunk);}try{return JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{fail('INVALID_JSON','JSON inválido.');}}
async function handler(req,res){
 try{
  const origin=req.headers.origin||'';
  if(origin&&!/^chrome-extension:\/\/[a-z]{32}$/.test(origin))fail('FORBIDDEN_ORIGIN','Origem não autorizada.',403);
  if(origin){res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');res.setHeader('Access-Control-Allow-Headers','Authorization, Content-Type');res.setHeader('Access-Control-Allow-Methods','GET,POST,PUT,DELETE,OPTIONS');}
  if(req.method==='OPTIONS'){res.writeHead(204);res.end();return;}
  if(!tokenMatches(String(req.headers.authorization||'').replace(/^Bearer\s+/i,'')))fail('UNAUTHORIZED','Token administrativo inválido.',401);
  const u=new URL(req.url,'http://127.0.0.1');const p=u.pathname;
  if(req.method==='GET'&&p==='/api/health')return json(res,200,{ok:true,service:'sra-luck-ai',version:'1.4.0'});
  if(req.method==='GET'&&p==='/api/state')return json(res,200,publicState());
  if(req.method==='POST'&&p==='/api/connections'){
   const body=await readBody(req);if(!allowedKinds.includes(body.type))fail('INVALID_PROVIDER','Tipo de provedor inválido.');
   const entry=body.id?state.connections.find(c=>c.id===body.id):null;
   if(body.id&&!entry)fail('NOT_FOUND','Conexão não encontrada.',404);
   if(!entry&&state.connections.length>=20)fail('LIMIT','Máximo de 20 conexões.');
   const candidate={...(entry||{}),id:entry?.id||crypto.randomUUID(),name:String(body.name||entry?.name||body.type).slice(0,70),type:body.type,base_url:String(body.base_url||'').trim(),enabled:body.enabled!==false,models:entry?.models||[]};
   parseTarget(candidate);
   // Uma chave vinculada a um serviço não pode ser reutilizada em outro tipo/host por engano.
   if(entry&&(entry.type!==candidate.type||entry.base_url!==candidate.base_url)&&body.api_key===undefined)candidate.secret='';
   if(body.api_key!==undefined){if(String(body.api_key).length>1000||/[\r\n]/.test(String(body.api_key)))fail('INVALID_KEY','Chave inválida ou acima do limite.');candidate.secret=encrypt(body.api_key);}
   if(candidate.type==='freellmapi'&&!candidate.secret)fail('INVALID_KEY','FreeLLMAPI requer uma chave unificada.');
   if(entry)Object.assign(entry,candidate);else state.connections.push(candidate);save();return json(res,200,{id:candidate.id,ok:true});
  }
  const m=p.match(/^\/api\/connections\/([\w-]+)\/(discover|test)$/);
  if(m&&req.method==='POST'){
   if(m[2]==='discover')return json(res,200,await discover(m[1]));
   const c=getConnection(m[1]);const details=await discover(c.id);return json(res,200,{ok:true,models:details.models,latency_ms:details.latency_ms});
  }
  const rm=p.match(/^\/api\/connections\/([\w-]+)$/);
  if(rm&&req.method==='DELETE'){
   state.connections=state.connections.filter(c=>c.id!==rm[1]);for(const a of Object.values(state.agents)){if(a.primary===rm[1]){a.primary='';a.model='';}a.fallback=a.fallback.filter(f=>f.id!==rm[1]);}save();return json(res,200,{ok:true});
  }
  if(req.method==='PUT'&&p==='/api/settings'){
   const body=await readBody(req);
   if(typeof body.free_only==='boolean')state.policy.free_only=body.free_only;
   for(const name of Object.keys(profiles))if(body.agents?.[name]){
    const b=body.agents[name];const valid=x=>!x||state.connections.some(c=>c.id===x);
    if(!valid(b.primary))fail('INVALID_ROUTE','Conexão principal inexistente.');
    const routes=(Array.isArray(b.fallback)?b.fallback:[]).slice(0,2).map(r=>({id:String(r.id),model:String(r.model).slice(0,180)}));
    if(routes.some(r=>!valid(r.id)))fail('INVALID_ROUTE','Alternativa inexistente.');
    state.agents[name]={primary:String(b.primary||''),model:String(b.model||'').slice(0,180),fallback:routes,allowExternal:b.allowExternal===true};
   }
   save();return json(res,200,publicState());
  }
  if(req.method==='POST'&&p==='/api/generate'){
   const body=await readBody(req),id=body.request_id;
   if(id!==undefined){
    if(typeof id!=='string'||!/^[-a-zA-Z0-9_]{16,90}$/.test(id))fail('INVALID_REQUEST_ID','Identificador de requisição inválido.');
    for(const [key,ts] of recentlyUsedRequests)if(Date.now()-ts>120000)recentlyUsedRequests.delete(key);
    if(recentlyUsedRequests.has(id))fail('DUPLICATE_REQUEST','Solicitação repetida bloqueada para evitar duplicação de chamadas.',409);
    recentlyUsedRequests.set(id,Date.now());
   }
   return json(res,200,await generate(body));
  }
  fail('NOT_FOUND','Rota não encontrada.',404);
 }catch(error){const known=error instanceof ApiError;json(res,known?error.status:500,{error:{code:known?error.code:'INTERNAL_ERROR',message:known?error.message:'Falha interna do serviço.',retryable:!!error.retryable}});}
}
const server=http.createServer((req,res)=>{void handler(req,res);});
server.requestTimeout=45000;server.headersTimeout=10000;server.listen(PORT,HOST,()=>console.log(`Sra. Luck IA 1.4.0 ativa apenas em http://${HOST}:${PORT} (autenticação obrigatória).`));
