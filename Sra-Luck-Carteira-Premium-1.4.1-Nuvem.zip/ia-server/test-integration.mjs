// Integração com serviços de API FICTÍCIOS locais: não mede disponibilidade real de fornecedores.
import http from 'node:http';import {spawn} from 'node:child_process';import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import assert from 'node:assert/strict';
const root=path.dirname(new URL(import.meta.url).pathname),dir=fs.mkdtempSync(path.join(os.tmpdir(),'sraluck-ai-test-'));
const admin='test-admin-token-12345678901234567890123456789',master='test-master-secret-123456789012345678901234567890';
let attempts={ollama:0,free:0}, ollamaOffline=false, slow=false, failOllama=false, failFree=false, freeFailureStatus=503, lastSent='';
function mock(port,handler){return new Promise(resolve=>{const server=http.createServer(async(req,res)=>{let input='';for await(const c of req)input+=c;const value=input?JSON.parse(input):{};handler(req,res,value);});server.listen(port,'127.0.0.1',()=>resolve(server));});}
function respond(res,code,data){res.writeHead(code,{'Content-Type':'application/json'});res.end(JSON.stringify(data));}
const ollama=await mock(11434,(req,res,body)=>{
 if(ollamaOffline){res.destroy();return;}
 if(req.url==='/v1/models'){respond(res,200,{data:[{id:'qwen3:4b'},{id:'gemma:2b'}]});return;}
 if(req.url==='/v1/chat/completions'){respond(res,200,{model:body.model,choices:[{message:{content:'Ollama compatível de teste.'}}]});return;}
 if(req.url==='/api/tags'){respond(res,200,{models:[{name:'qwen3:4b'},{name:'gemma:2b'}]});return;}
 if(req.url==='/api/chat'){
  attempts.ollama++;lastSent=JSON.stringify(body);
  if(slow)return;
  if(failOllama){respond(res,503,{error:'server busy'});return;}
  respond(res,200,{model:body.model,message:{content:'Mensagem humanizada de teste.'},prompt_eval_count:12,eval_count:9});return;
 }
 respond(res,404,{error:'unknown'});
});
const free=await mock(31415,(req,res,body)=>{
 if(req.headers.authorization!=='Bearer test-secret'){respond(res,401,{error:'invalid key'});return;}
 if(req.url==='/v1/models?execution_status=ready'){respond(res,200,{data:[{id:'auto'},{id:'auto:fast'},{id:'auto:smart'},{id:'auto:reliable'},{id:'mock-freemodel',execution_status:'ready'}]});return;}
 if(req.url==='/v1/chat/completions'){attempts.free++;if(failFree){respond(res,freeFailureStatus,{error:'busy'});return;}respond(res,200,{model:body.model,choices:[{message:{content:'Resposta fictícia FreeLLMAPI'}}],usage:{prompt_tokens:14,completion_tokens:17}});return;}
 respond(res,404,{error:'unknown'});
});
const proc=spawn(process.execPath,[path.join(root,'server.mjs')],{env:{...process.env,SRA_LUCK_PORT:'45421',SRA_LUCK_MASTER_KEY:master,SRA_LUCK_ADMIN_TOKEN:admin,SRA_LUCK_DATA_DIR:dir,SRA_LUCK_PROVIDER_TIMEOUT_MS:'550'},stdio:['ignore','pipe','pipe']});let output='';proc.stderr.on('data',c=>output+=c);
const base='http://127.0.0.1:45421';async function call(route,method='GET',body,token=admin){const r=await fetch(base+route,{method,headers:{'Authorization':'Bearer '+token,'Content-Type':'application/json','Origin':'chrome-extension://abcdefghijklmnopabcdefghijklmnop'},...(body?{body:JSON.stringify(body)}:{})});return {status:r.status,data:await r.json()};}
let waited=0;while(waited<3500){try{await call('/api/health');break;}catch{await new Promise(r=>setTimeout(r,50));waited+=50;}}
let total=0;function check(b,msg){assert(b,msg);total++;}
try{
 let r=await call('/api/health','GET',undefined,'wrong');check(r.status===401,'sem token bloqueado');
 r=await call('/api/state');check(r.data.policy.free_only===true,'free_only default');
 r=await call('/api/connections','POST',{type:'ollama',name:'Ollama teste',base_url:'http://127.0.0.1:11434',enabled:true});check(r.status===200,'cadastra Ollama');const ollamaId=r.data.id;
 r=await call(`/api/connections/${ollamaId}/discover`,'POST');check(r.data.models.some(m=>m.id==='qwen3:4b'),'tags reais do mock');
 r=await call('/api/settings','PUT',{agents:{cobranca:{primary:ollamaId,model:'qwen3:4b',allowExternal:false,fallback:[]},atendimento:{primary:ollamaId,model:'gemma:2b',allowExternal:false,fallback:[]}}});check(r.status===200,'agentes distintos');
 const sample={agent:'cobranca',context_authorized:true,task:'reply',messages:[{role:'user',content:'Olá CPF 123.456.789-01; como posso pagar?'}]};
 r=await call('/api/generate','POST',sample);check(r.status===200&&r.data.provider===ollamaId,'gera no Ollama');check(!lastSent.includes('123.456.789-01')&&lastSent.includes('[CPF oculto]'),'mascaramento obrigatório');
 r=await call('/api/connections','POST',{type:'ollama_openai',name:'Ollama OAI mock',base_url:'http://127.0.0.1:11434'});check(r.status===200,'cadastra Ollama OpenAI-compatible');const ollamaCompat=r.data.id;
 r=await call(`/api/connections/${ollamaCompat}/discover`,'POST');check(r.data.models.some(m=>m.id==='qwen3:4b'),'Ollama modelo pela API /v1/models');
 await call('/api/settings','PUT',{agents:{atendimento:{primary:ollamaCompat,model:'qwen3:4b',allowExternal:false,fallback:[]}}});
 r=await call('/api/generate','POST',{...sample,agent:'atendimento'});check(r.status===200&&r.data.text.includes('compatível'),'Ollama /v1/chat/completions');
 r=await call('/api/connections','POST',{type:'freellmapi',name:'Free mock',base_url:'http://127.0.0.1:31415/v1',api_key:'test-secret'});check(r.status===200,'cadastro freeLLM');const freeId=r.data.id;
 r=await call(`/api/connections/${freeId}/discover`,'POST');check(r.data.models.some(m=>m.id==='auto:smart'),'modelos filtrados');
 r=await call('/api/state');check(!JSON.stringify(r.data).includes('test-secret'),'credencial nunca devolvida');check(r.data.agents.atendimento.primary===ollamaCompat&&r.data.agents.cobranca.primary===ollamaId,'agentes isolados');
 const store=fs.readFileSync(path.join(dir,'connections.json'),'utf8');check(!store.includes('test-secret'),'credencial criptografada em disco');
 r=await call('/api/settings','PUT',{agents:{cobranca:{primary:freeId,model:'auto:smart',allowExternal:true,fallback:[]}}});
 r=await call('/api/generate','POST',sample);check(r.status===403&&r.data.error.code==='FREE_ONLY_BLOCK','bloqueia externo com free_only');
 r=await call('/api/settings','PUT',{free_only:false,agents:{cobranca:{primary:freeId,model:'auto:smart',allowExternal:false,fallback:[]}}});
 r=await call('/api/generate','POST',sample);check(r.status===403&&r.data.error.code==='CONSENT_REQUIRED','bloqueia sem autorização externa');
 r=await call('/api/settings','PUT',{agents:{cobranca:{primary:freeId,model:'auto:smart',allowExternal:true,fallback:[]}}});
 r=await call('/api/generate','POST',sample);check(r.status===200&&r.data.text.includes('fictícia'),'modelo auto:smart no FreeLLMAPI');
 r=await call('/api/connections','POST',{id:freeId,type:'freellmapi',name:'Free mock',base_url:'http://127.0.0.1:31415/v1',api_key:'bad-key'});
 r=await call(`/api/connections/${freeId}/test`,'POST');check(r.status===502,'chave incorreta');
 await call('/api/connections','POST',{id:freeId,type:'freellmapi',name:'Free mock',base_url:'http://127.0.0.1:31415/v1',api_key:'test-secret'});
 failFree=true;await call('/api/settings','PUT',{agents:{cobranca:{primary:freeId,model:'auto:smart',allowExternal:true,fallback:[{id:ollamaId,model:'qwen3:4b'}]}}});
 const before=attempts.ollama;r=await call('/api/generate','POST',sample);check(r.status===503&&attempts.ollama===before,'FreeLLMAPI auto:smart sem fallback duplicado');
 await call('/api/settings','PUT',{agents:{cobranca:{primary:freeId,model:'mock-freemodel',allowExternal:true,fallback:[{id:ollamaId,model:'qwen3:4b'}]}}});
 r=await call('/api/generate','POST',sample);check(r.status===200&&r.data.provider===ollamaId,'fallback autorizado no 503');
 freeFailureStatus=429;r=await call('/api/generate','POST',sample);check(r.status===200&&r.data.provider===ollamaId,'fallback autorizado no 429');
 failFree=false;slow=true;await call('/api/settings','PUT',{agents:{cobranca:{primary:ollamaId,model:'qwen3:4b',allowExternal:false,fallback:[]}}});
 r=await call('/api/generate','POST',sample);check(r.status===504&&r.data.error.code==='TIMEOUT','timeout claro e limitado');slow=false;
 r=await call('/api/settings','PUT',{free_only:true,agents:{cobranca:{primary:ollamaId,model:'qwen3:4b',allowExternal:false,fallback:[]}}});
 const requestId={...sample,request_id:'unique-idempotency-key-123456789'};
 r=await call('/api/generate','POST',requestId);check(r.status===200,'primeira requisição com idempotência');
 r=await call('/api/generate','POST',requestId);check(r.status===409&&r.data.error.code==='DUPLICATE_REQUEST','bloqueio de duplicação');
 r=await call('/api/settings','PUT',{free_only:true,agents:{cobranca:{primary:ollamaId,model:'nao-instalada',allowExternal:false,fallback:[]}}});
 r=await call('/api/generate','POST',sample);check(r.status===403&&r.data.error.code==='FREE_MODEL_UNVERIFIED','modelo inexistente bloqueado');
 r=await call('/api/connections','POST',{type:'openai_compatible',name:'ssrf',base_url:'http://169.254.169.254/latest'});check(r.status===400,'SSRF bloqueado');
 r=await call('/api/connections','POST',{type:'ollama',name:'outra porta',base_url:'http://127.0.0.1:9999'});check(r.status===400,'porta local não permitida');
 r=await call('/api/generate','POST',{...sample,context_authorized:false});check(r.status===403,'contexto sem autorização bloqueado');
 r=await call('/api/state');check(r.data.logs.every(x=>!JSON.stringify(x).includes('CPF')&&!JSON.stringify(x).includes('test-secret')),'logs sem conteúdo sensível');
 ollamaOffline=true;r=await call(`/api/connections/${ollamaId}/discover`,'POST');check(r.status===502,'Ollama offline detectado');
 console.log(`PASSARAM ${total} verificações de integração com APIs simuladas.`);
}catch(e){console.error('FALHA',e,'SERVER ERR:',output);process.exitCode=1;}finally{proc.kill('SIGTERM');ollama.close();free.close();}
